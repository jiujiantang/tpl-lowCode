<template>
  <div class="app-container">
	 <div class="viewPageWrap">
        <div class="viewWrap">
            <!-- 预览 B! -->
            <div id="gamePreviewPage" class="game-preview-page">
                <!-- 中间的 路由 router-view 区域 -->
                <transition>
                    <router-view ></router-view>
                </transition>
            </div>
            <!-- 配置项 B! -->
            <div class="mx_configuration">
                <!-- 背景 B! -->
                <div class="controlP-BG_PAGE mx-controlP" :style="{ display: currControl == 'BG_PAGE' ? 'inline-block' :'none' }" >
                    <h1 class="mx-title mx-bottom-line">背景模块</h1>
                    <div class="mx_set_background_style">
                        <div class="controls">
                            <label class="radio inline"> 
                                <input type="radio" value="0" v-model="BG_PAGE.moduleBgType" @change="doModuleBgType" />系统预设
                                <input type="radio" value="1" v-model="BG_PAGE.moduleBgType" @change="doModuleBgType" />自定义样式<span class="help-inline">（图片上传）</span>
                            </label>
                        </div>
                        <div class="control-group" v-show="!Number( BG_PAGE.moduleBgType )">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>背景颜色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls">
                                <my-color-picker v-model="BG_PAGE.color"></my-color-picker>
                            </div>
                        </div>
                        <div class="control-group" v-show="!!Number( BG_PAGE.moduleBgType )">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>背景图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                            <div class="controls">
                                <input type="text" class="mx_input_short" value="" v-model="BG_PAGE.path"/>
                                <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);"  @click="browse">浏览...</a>
                                <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" @click="submitUpload">上传</a>
                                <a href="javascript:;" class="vb cover-recovery" @click="zero">恢复默认</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- 图片背景 B! -->
                <div class="controlP-BG_IMG mx-controlP" :style="{ display: currControl == 'BG_IMG' ? 'inline-block' :'none' }" id="IMG">
                    <h1 class="mx-title mx-bottom-line" >图片</h1>
                    <div class="control-group mx_upImg" >
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" value="" v-model="BG_IMG.route"/>
                            <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                            <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" @click="submitUpload">上传</a>
                            <a href="javascript:;" class="vb cover-recovery" @click="zero">恢复默认</a>
                        </div>
                    </div>
                </div>
                <!-- 文本编辑 B! -->
                <div class="controlP-P_WORD mx-controlP" :style="{ display: currControl == 'P_WORD' ? 'inline-block' :'none' }" >
                    <h1 class="mx-title mx-bottom-line">文本编辑</h1>
                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件内容<span class="help-inline"></span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" v-model="P_WORD.content"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>字号<span class="help-inline">(px)</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" v-model="P_WORD.fontSize"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>行间距<span class="help-inline">(px)</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" v-model="P_WORD.height"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>颜色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls" id="textColorPicker">
                                <my-color-picker :defaultColor="P_WORD.defaultColor" v-model="P_WORD.color" ref="mychild"></my-color-picker>
                            </div>
                        </div>
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>背景色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls">
                                <my-color-picker :defaultColor="'none'"  v-model="P_WORD.background"></my-color-picker>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- 卡片模块设置 B！-->
                <div class="controlP-CARD_NORMAL mx-controlP" :style="{ display: currControl == 'CARD_NORMAL' ? 'inline-block' :'none' }" >
                    <h1 class="mx-title mx-bottom-line">卡片模块</h1>
                    <div class="controls">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件名称<span class="help-inline"></span></h2>
                        <label class="radio inline"> 
                            <input type="text" v-model="CARD_NORMAL.name"/><br>
                        </label>
                    </div>
                    <div class="controls">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>按钮数量<span class="help-inline"></span></h2>
                        <label class="radio inline"> 
                            <input type="radio" value="0" v-model="CARD_NORMAL.num" checked="checked"/>一个 <br>
                            <input type="radio" value="1" v-model="CARD_NORMAL.num" />两个 <br>
                        </label>
                    </div>
                    <div class="controls">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件状态<span class="help-inline"></span></h2>
                        <label class="radio inline"> 
                            <input type="radio" value="0" v-model="CARD_NORMAL.status" checked="checked"/>立即抢券 
                            <input type="radio" value="1" v-model="CARD_NORMAL.status" />已抢光 
                        </label>
                    </div>
                    <div class="controls">  
                        <label class="radio inline"> 
                            <input type="radio" value="0" v-model="CARD_NORMAL.moduleBgType" @change="doModuleBgType" checked="checked"/>系统预设
                            <input type="radio" value="1" v-model="CARD_NORMAL.moduleBgType" @change="doModuleBgType"/>自定义样式（图片上传）
                        </label>
                    </div>
                    <div class="control-group clearfix" v-show="CARD_NORMAL.moduleBgType == 0">
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件颜色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls">
                                <my-color-picker v-model="CARD_NORMAL.color"></my-color-picker>
                            </div>
                        </div>
                        <div class="control-group fl" style="margin-left: 10px;" v-show="currEdit != 'rightsBg' && currEdit != 'rightsBg1'">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>按钮颜色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls">
                                    <my-color-picker v-model="CARD_NORMAL.btnColor"></my-color-picker>
                            </div>
                        </div>
                    </div>
                    <div class="control-group" v-show="CARD_NORMAL.moduleBgType == 1">
                        <div class="control-group mx_upImg" >
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>卡片图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                            <div class="controls">
                                <input type="text" class="mx_input_short" value="" v-model="CARD_NORMAL.path"/>
                                <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                                <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" @click="submitUpload">上传</a>
                                <a href="javascript:;" class="vb cover-recovery" @click="zero">恢复默认</a>
                            </div>
                        </div>
                        <div class="control-group mx_upImg" v-show="currEdit != 'rightsBg' && currEdit != 'rightsBg1'">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>按钮图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                            <div class="controls">
                                <input type="text" class="mx_input_short" value="" v-model="CARD_NORMAL.path1"/>
                                <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                                <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" data-id="1" @click="submitUpload">上传</a>
                                <a href="javascript:;" class="vb cover-recovery"  data-id="1" @click="zero">恢复默认</a>
                            </div>
                        </div>
                    </div>

                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>链接<span class="help-inline">（必须以http://或https://开始）</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" value="输入链接" v-model="CARD_NORMAL.link"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>站外点击唤起方式<span class="help-inline"></span></h2>
                        <div class="controls">
                            <select name="awardType" class="span2" data-editable="false" v-model="CARD_NORMAL.way" >
                                <option value="0">点击唤起招商银行APP</option>
                                <option value="1">点击仅跳转至链接</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- 卡片模块设置-图文 B！-->
                <div class="controlP-CARD_IMG mx-controlP" :style="{ display: currControl == 'CARD_IMG' ? 'inline-block' :'none' }" >
                    <h1 class="mx-title mx-bottom-line">卡片模块设置</h1>
                    <div class="controls">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>样式<span class="help-inline"></span></h2>
                        <label class="radio inline"> 
                            <input type="radio" value="0" v-model="CARD_IMG.moduleBgType" @change="doModuleBgType" />左图右文
                            <input type="radio" value="1" v-model="CARD_IMG.moduleBgType" @change="doModuleBgType" />右图左文
                        </label>
                    </div>
                    <div class="control-group" v-show="CARD_IMG.moduleBgType == 0">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>背景图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" value="" v-model="CARD_IMG.path"/>
                            <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                            <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" @click="submitUpload">上传</a>
                            <a href="javascript:;" class="vb cover-recovery" @click="zero">恢复默认</a>
                        </div>
                    </div>
                    <div class="control-group" v-show="CARD_IMG.moduleBgType == 1">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>背景图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" value="" v-model="CARD_IMG.path1"/>
                            <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                            <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" data-id="1" @click="submitUpload">上传</a>
                            <a href="javascript:;" class="vb cover-recovery" data-id="1" @click="zero">恢复默认</a>
                        </div>
                    </div>
                </div>
                <!-- 视频组件 B! -->
                <div class="controlP-P_VIDEO mx-controlP" :style="{ display: currControl == 'P_VIDEO' ? 'inline-block' :'none' }" >
                    <h1 class="mx-title">视频组件</h1>
                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件名称<span class="help-inline"></span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" v-model="P_VIDEO.name" value="输入文字"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>视频地址<span class="help-inline">（必须从招呼平台上传）</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" v-model="P_VIDEO.link" value="输入链接"/>
                        </div>
                    </div>
                    <div class="control-group mx_upImg" >
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                        <div class="controls">
                            <input type="text" class="mx_input_short" value="" v-model="P_VIDEO.path"/>
                            <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                            <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" @click="submitUpload">上传</a>
                            <a href="javascript:;" class="vb cover-recovery" @click="zero">恢复默认</a>
                        </div>
                    </div>
                </div>
                <!-- 导航组件 B! -->
                <div class="controlP-NAVIGATION mx-controlP" :style="{ display: currControl == 'NAVIGATION' ? 'inline-block' :'none' }" >
                    <h1 class="mx-title">导航组件</h1>
                    <div class="controls">
                        <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件名称<span class="help-inline"></span></h2>
                        <label class="radio inline"> 
                            <input type="text" v-model="NAVIGATION.name"/><br>
                        </label>
                    </div>
                    <div class="controls">
                        <label class="radio inline"> 
                            <input type="radio" name="cardType" value="0" v-model="NAVIGATION.moduleBgType" checked="checked"/>系统预设
                            <input type="radio" name="cardType" value="1" v-model="NAVIGATION.moduleBgType"/>自定义样式（图片上传）
                        </label>
                    </div>
                    <div class="control-group"  v-show="NAVIGATION.moduleBgType == 0">
                        <div class="control-group">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件样式<span class="help-inline">（点击即应用样式）</span></h2>
                            <div class="controls">
                                <ul class="navigationType">
                                    <li ><div class="btn style1" data-type="0" @click="check"></div></li>
                                    <li ><div class="btn style2" data-type="1" @click="check"></div></li>
                                    <li ><div class="btn style3" data-type="2" @click="check"></div></li>
                                    <li ><div class="btn style4" data-type="3" @click="check"></div></li>
                                    <li ><div class="btn style5" data-type="4" @click="check"></div></li>
                                    <li ><div class="btn style6" data-type="5" @click="check"></div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="control-group"  v-show="NAVIGATION.moduleBgType == 1">
                        <div class="control-group mx_upImg" >
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>图片<span class="help-inline">（限10M以内，jpg/jpge/png/gif格式图片）</span></h2>
                            <div class="controls">
                                {{NAVIGATION.path}}
                                <input type="text" class="mx_input_short" value="" v-model="NAVIGATION.path"/>
                                <a class="mx-btn mx-btn-NORMAL" href="javascript:void(0);" @click="browse">浏览...</a>
                                <a class="mx-btn mx-btn-FILLED" href="javascript:void(0);" @click="submitUpload">上传</a>
                                <a href="javascript:;" class="vb cover-recovery" @click="zero">恢复默认</a>
                            </div>
                        </div>
                    </div>
                    <div class="control-group clearfix">
                        <div class="control-group fl" v-show="NAVIGATION.moduleBgType == 0">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>组件颜色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls">
                                <my-color-picker :defaultColor="'#87B9DA'" v-model="NAVIGATION.background"></my-color-picker>
                            </div>
                        </div>
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>字体颜色<span class="help-inline">（点击选中颜色）</span></h2>
                            <div class="controls">
                                <my-color-picker :defaultColor="'#87B9DA'" v-model="NAVIGATION.color"></my-color-picker>
                            </div>
                        </div>
                    </div>
                    <div class="control-group clearfix">
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>文字内容<span class="help-inline"></span></h2>
                            <div class="controls">
                                <input type="text" class="mx_input_short" v-model="NAVIGATION.content" value="输入文字"/>
                            </div>
                        </div>
                        <div class="control-group fl" style="margin-left:10px;" v-show="NAVIGATION.moduleBgType == 0">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>边框宽度<span class="help-inline">(px)</span></h2>
                            <div class="controls">
                                <input type="text" class="mx_input_short" v-model="NAVIGATION.borderWidth" value="0"/>
                            </div>
                        </div>
                    </div>
                    <div class="control-group clearfix">
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>链接<span class="help-inline">（必须以http://或https://开始）</span></h2>
                            <div class="controls">
                                <input type="text" class="mx_input_short" value="0"  v-model="NAVIGATION.link"/>
                            </div>
                        </div>
                        <div class="control-group fl">
                            <h2 class="mx-subtitle"><span class="mx-maroon">*</span>站外点击唤起方式<span class="help-inline"></span></h2>
                            <div class="controls">
                                <select name="clickType" v-model="NAVIGATION.way">
                                    <option value="1">点击唤起招商银行APP</option>
                                    <option value="2">点击仅跳转至链接</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mx_bottomBar mx_bottomBarBig mx-top-line">
                    <div class="controls mx-center" :style="{'display' : currControl === 'none' ? 'none' : 'inline-block'}">
                        <a class="mx-btn mx-btn-NORMAL mx-btn-MIDDLE" href="javascript:void(0);" @click="cancel">取消</a>
                        <a class="mx-btn mx-btn-FILLED mx-btn-MIDDLE" href="javascript:void(0);" v-show = "edit" @click="determine">确定</a>
                    </div>
                </div>
            </div>
            <div class="pageBottom">
                <div class="wrap">
                    <div class="before mx-btn mx-btn-NORMAL mx-btn-MIDDLE" @click="before">上一步</div>
                    <div class="submit mx-btn mx-btn-FILLED mx-btn-MIDDLE" @click="temSubmit" v-show = "edit">保存</div>
                </div>
            </div>
            <!-- TODO 对接-上传图片 B! -->
            <div class="pic">
                <el-upload
                    ref="upload"
                    :action="url"
                    :on-preview="handlePreview"
                    :on-remove="handleRemove"
                    :auto-upload="false"
                    :data="resData"
                    :on-success="onSuccess"
                    :on-error="onError"
                    :on-progress="onProgress"
                    :on-change="onChange"
                    :limit="1"
                >
                <i class="el-icon-plus"></i>
                <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                <el-button style="margin-left: 10px;" size="small" type="success" @click="submitUpload">上传到服务器</el-button>
                </el-upload>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import pageJson from './pageJson.json'
const staticJson = JSON.parse(JSON.stringify( pageJson ))

export default {
    data() {
        return {
            dark: false,
            edit: true,
            currControl: 'BG_IMG',
            currEdit: 'screenBg',
            currIndex: 0,
            currText: 0,
            currStatusId: 0,
            upControlId: '',
            BG_PAGE: {
                moduleBgType: '1',
                color: "#000",
                path: "",
            },
            BG_IMG: {
                path: "",
            },
            P_WORD: {
                defaultColor: "#000",
                content: "笔笔享立减",
                color: "#FEDFC0",
                background: "none",
                height: "24",
                lineHeight: "24",
                fontSize: "14"
            },
            CARD_NORMAL: {
                name: "用户特权",
                num: 1,
                moduleBgType: '1',
                color: "#000",
                btnColor: "#000",
                link: "http://m.cmbchina.com",
                way: 1,
                path: "",
                path1: "",
                status: 0 
            },
            CARD_IMG: {
                moduleBgType: '1',
                path: "",
                path1: "",
            },
            P_VIDEO: {
                name: "视频",
                link: "",
                path: "",
            },
            NAVIGATION: {
                name:"按钮",
                type: 2,
                background: "none",
                content: "查看更多热映影片>>",
                color: "#FEDFC0",
                borderWidth: "2",
                way: 1,
                link: "http://m.cmbchina.com",
                moduleBgType: 1,
                height: "24",
                lineHeight: "24",
                fontSize: "14",
                defaultColor: "#000",
                path: "",
            },
            originalJson: '',
            renderJson: '',
            machineId: '',
            resData: {// TODO 图片上传参数
                imgtype: "2",
                filename: "pic" + (new Date() - new Date(1970,1,1)),
                tplRelativePath: ""
            },
            url: "/MPageManage/Mpage/PicUpload"// TODO 图片上传域名
        };
    },
    created() {
        //初始化
        this.submit(pageJson);
        var $this = this;
        window.addEventListener("message", function(messageEvt){
            try{
                if(messageEvt.data === "" || messageEvt.data === undefined || messageEvt.data === null){
                    return false;
                }
                $this.submit(JSON.parse(messageEvt.data));
                $this.$store.commit("modifyResPath", window.parent.document.getElementById("resPath").value);
                $this.$store.commit("modifyStatus", $this.getStatus("opr") !== "1");
                $this.resData.tplRelativePath = $this.$store.state.resPath;
            }
            catch(e){}
        })
    },
    methods: {
        getStatus: function(name){
            var url = "?" + window.parent.location.href.split("?")[1];
            return  decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(url) || [, ""])[1].replace(/\+/g, '%20')) || "";
        },
        // 图片上传
        onSuccess:function(res){
            this.$refs.upload.clearFiles()
            if(res.Status == 0 ) {
                alert("图片上传成功！点击'确定'可以在左边预览哦~")
                this[ this.currControl ][ "path" + this.upControlId ] = res.RelativePath
            }else {
                alert(res.Msg)
            }
        },
        onError:function(res){
            this.$refs.upload.clearFiles()
            console.log( res )
        },
        before:function(){//取消
            window.parent.document.getElementById("frameCancel").click();
        },
        temSubmit:function(){//保存
            window.parent.document.getElementById("dataJson").value = JSON.stringify(this.originalJson);//json数据
            window.parent.document.getElementById("dataImg").value = JSON.stringify(this.getImgList());
			window.parent.document.getElementById("frameSave").click();
        },
        getImgList: function(){
            // path数组
            var pathArr = ["ruleBtn","ruleBg","screenBg","specialBgT","specialBgM","specialBgB","rightsBg","rightsBg1","priceBtn","newsBg","cover","hotLeft","hotRight","hotLeft2","ad","ad1","ad2","btn","btn1","btn2","adBg","iconCat","stickyBtn","mark","navigation"]
            var arr = []
            for( var i = 0; i < this.originalJson.length; i++ ) {
                var tpl = this.originalJson[i]
                for( var key in tpl ) {
                    if ( pathArr.indexOf(key) != -1){
                        for ( var j = 0; j < 3; j++ ){
                            if(this.originalJson[i][key]['src'] && this.originalJson[i][key]['src']['path' + (j == 0 ? '' : j)] ){
                                arr.push(this.originalJson[i][key]['src']['path' + (j == 0 ? '' : j)] )
                            }
                        }
                    }
                }
            }
            return arr;
        },
        onChange:function(file, fileList){
            if( !file.response ){
                alert("成功选中图片：" + file.name + "，快点击'上传'吧!")
            }
        },
        randomName() {
            var key = new Date().getTime() + Math.round(Math.random() * 100000) + '.jpg'
            var url = key
            this.resData.filename =  url
        },
        handleRemove(file, fileList) {
            console.log(file, fileList);
        },
        handlePreview(file) {
            alert(1)
            console.log(file);
        },
        onProgress(res) {
            console.log( res )
        },
        browse:function(){
            console.log($(".pic div.el-upload.el-upload--text span").length)
            $(".pic div.el-upload.el-upload--text span").trigger("click")
        },
        submitUpload(e) {
            if( $(e.target).attr("data-id") ){
                this.upControlId = $(e.target).attr("data-id")
            }else{
                this.upControlId = ''
            }      
            this.$refs.upload.submit();
        },
        zero( e ) {
            if( $(e.target).attr("data-id") ){
                this.upControlId = $(e.target).attr("data-id")
            }else{
                this.upControlId = ''
            }
            this[ this.currControl ][ "path" + this.upControlId ] = staticJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" + this.upControlId ]
        },
        submit( originalJson ) {
            this.$store.commit('modifyOriginalJson', originalJson)
            this.originalJson = this.$store.state.originalJson
        },
        doModuleBgType() {
            if( this.BG_PAGE.moduleBgType === "0" ){
                console.log( "0" )
            }else if( this.BG_PAGE.moduleBgType === "1" ){
                console.log( "1" )
            }
        },
        findControlP( type ) {// 选中的控制面板类型
            this.currControl = type
        },
        findJsonIndex( index ) {// 模块数据在json数组的索引
            this.currIndex = index
        },
        findComponents( name ) {// 组件名字
            this.currEdit = name
        },
        finddefaultColor( defaultColor ) {// 当前字体默认颜色
            this.P_WORD.defaultColor = defaultColor
        },
        findContentId( contentId ) {// 当前文本索引
            this.currText = contentId
        },
        findStatusId( statusId ) {// 当前按钮索引
            this.currStatusId = statusId
        },
        check( e ){
            this.NAVIGATION.type = $(e.target).attr("data-type")
            $(".navigationType li").css({"border":"none"})
            $(e.target).parent("li").css({"border":"dashed #999 1px"})
        },
        cancel() {
            this.currControl = "none"
        },
        determine() {
            this.builtJson()
            this.cancel()

        },
        builtJson() {
            if( this.currControl == "BG_PAGE" ) {
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ] = this[ this.currControl ][ "path" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ] = this[ this.currControl ][ "moduleBgType" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "color" ] = this[ this.currControl ][ "color" ]
            }else if( this.currControl == "BG_IMG") {
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ] = this[ this.currControl ][ "path" ]
            }else if( this.currControl == "P_WORD" ){
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "content"+this.currText ] = this[ this.currControl ][ "content" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "color" ] = this[ this.currControl ][ "color" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "height" ] = this[ this.currControl ][ "height" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "lineHeight" ] = this[ this.currControl ][ "height" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "fontSize" ] = this[ this.currControl ][ "fontSize" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "background" ] = this[ this.currControl ][ "background" ]
            }else if( this.currControl == "CARD_NORMAL" ){
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "name" ] = this[ this.currControl ][ "name" ]
                if( this.currEdit== "rightsBg" || this.currEdit== "rightsBg1" ){
                    this.originalJson[ Number( this.currIndex ) ][ "rightsBg" ][ "custom" ][ "num" ] = this[ this.currControl ][ "num" ]
                    this.originalJson[ Number( this.currIndex ) ][ "rightsBg1" ][ "custom" ][ "num" ] = this[ this.currControl ][ "num" ]
                }else {
                    this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "num" ] = this[ this.currControl ][ "num" ]
                }
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "status"+this.currStatusId ] = this[ this.currControl ][ "status" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ] = this[ this.currControl ][ "path" ]
                if( this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ] ) this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ] = this[ this.currControl ][ "path1" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ] = this[ this.currControl ][ "moduleBgType" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "color" ] = this[ this.currControl ][ "color" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "btnColor" ] = this[ this.currControl ][ "btnColor" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "link" ] = this[ this.currControl ][ "link" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "way" ] = this[ this.currControl ][ "way" ]
            }else if( this.currControl == "P_VIDEO" ){
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ] = this[ this.currControl ][ "path" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "name" ] = this[ this.currControl ][ "name" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "link" ] = this[ this.currControl ][ "link" ]
            }else if( this.currControl == "CARD_IMG" ){
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ] = this[ this.currControl ][ "path" ]
                if( this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ] ) this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ] = this[ this.currControl ][ "path1" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ] = this[ this.currControl ][ "moduleBgType" ]
            }else if( this.currControl == "NAVIGATION" ){
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "name" ] = this[ this.currControl ][ "name" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "type" ] = this[ this.currControl ][ "type" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "content"+this.currText ] = this[ this.currControl ][ "content" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "background" ] = this[ this.currControl ][ "background" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "color" ] = this[ this.currControl ][ "color" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "borderWidth" ] = this[ this.currControl ][ "borderWidth" ] 
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "link" ] = this[ this.currControl ][ "link" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "way" ] = this[ this.currControl ][ "way" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ] = this[ this.currControl ][ "moduleBgType" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ] = this[ this.currControl ][ "path" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "lineHeight" ] = this[ this.currControl ][ "height" ]
                this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "fontSize" ] = this[ this.currControl ][ "fontSize" ] 
            }
        },
        builtReverse() {
            if( this.currControl == "BG_PAGE" ) {
                this[ this.currControl ][ "path" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ]
                this[ this.currControl ][ "moduleBgType" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ]
                this[ this.currControl ][ "color" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "color" ]
            }else if( this.currControl == "BG_IMG" ) {
                this[ this.currControl ][ "path" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ]
            }else if( this.currControl == "P_WORD" ){
                this[ this.currControl ][ "content" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "content"+this.currText ]
                this[ this.currControl ][ "color" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "color" ]
                this[ this.currControl ][ "height" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "lineHeight" ]
                this[ this.currControl ][ "fontSize" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "fontSize" ]
                this[ this.currControl ][ "background" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "background" ]
            }else if( this.currControl == "CARD_NORMAL" ){
                this[ this.currControl ][ "name" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "name" ]
                this[ this.currControl ][ "num" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "num" ]
                this[ this.currControl ][ "status" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "status"+this.currStatusId ]
                this[ this.currControl ][ "path" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ]
                if( this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ] )  this[ this.currControl ][ "path1" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ]
                this[ this.currControl ][ "moduleBgType" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ]
                this[ this.currControl ][ "color" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "color" ]
                this[ this.currControl ][ "btnColor" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "btnColor" ]
                this[ this.currControl ][ "link" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "link" ]
                this[ this.currControl ][ "way" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "way" ]
            }else if ( this.currControl == "P_VIDEO" ){
                this[ this.currControl ][ "path" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ]
                this[ this.currControl ][ "name" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "name" ]
                this[ this.currControl ][ "link" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "link" ]
            }else if( this.currControl == "CARD_IMG" ){
                this[ this.currControl ][ "path" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ]
                if( this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ] )  this[ this.currControl ][ "path1" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path1" ]
                this[ this.currControl ][ "moduleBgType" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ]
            }else if( this.currControl == "NAVIGATION" ){
                this[ this.currControl ][ "name" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "name" ]
                this[ this.currControl ][ "type" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "type" ]
                this[ this.currControl ][ "content" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "content"+this.currText ]
                this[ this.currControl ][ "background" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "background" ]
                this[ this.currControl ][ "color" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "color" ]
                this[ this.currControl ][ "borderWidth" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "borderWidth" ]
                this[ this.currControl ][ "link" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "link" ]
                this[ this.currControl ][ "way" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "way" ]
                this[ this.currControl ][ "moduleBgType" ]  = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "moduleBgType" ]
                this[ this.currControl ][ "path" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "src" ][ "path" ]
                this[ this.currControl ][ "height" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "lineHeight" ]
                this[ this.currControl ][ "fontSize" ] = this.originalJson[ Number( this.currIndex ) ][ this.currEdit ][ "custom" ][ "style" ][ "fontSize" ]
            
            }
        }
    },
    mounted() {
        var that = this
        var $editTarget = $(".editTarget")
        var html = '<div class="drap-resize_main" style="top: 0px; left: 0px; width: 100%; height: 100%; z-index: 0; transform: rotate(0deg); box-sizing: border-box;"></div>'
        $editTarget.append( html )
        $editTarget.each(function(index, dom){
            (function(){
                $(dom).on("click",function(e){
                $('.drap-resize_main').removeClass('active')
                $(dom).find('.drap-resize_main:last').addClass('active')
                var type = $(dom).attr('data-type')
                var name = $(dom).attr('data-name')
                var index = $(dom).attr('data-index')
                var defaultColor = $(dom).attr('data-defaultColor')
                var contentId = $(dom).attr('data-contentId')
                var statusId = $(dom).attr('data-statusId')
                console.info("type：" + type + "; index:" + index + "; name：" + name + "; defaultColor:" + defaultColor + "; contentId:" + contentId + "; statusId:" + statusId )
                that.findControlP( type )
                that.findJsonIndex( index )
                that.findComponents( name )
                that.findContentId( contentId )
                that.findStatusId( statusId ) 
                // 
                if ( defaultColor ) {
                    that.finddefaultColor( defaultColor )
                    setTimeout( function(){
                        that.$refs.mychild.handleDefaultColor()
                    }, 0 )
                }
                // 回填
                that.builtReverse()

                return false;
                })
            })(dom);
        })
        
        var docEl = document.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            $("#gamePreviewPage").css("marginLeft",(clientWidth/2 - 375) + "px")
            $(".mx_configuration").css("left",(clientWidth/2 + 18) + "px")
            $(".mx-controlP").css("max-height", docEl.clientHeight - 133 + "px")
        };
        if (!document.addEventListener) return;
        window.addEventListener(resizeEvt, recalc, false);
        
        recalc();

        $(".screen-bg").trigger("click")
    }
};

</script>

<style lang="scss" scoped>
.vb {
    font-size: 13px;
    color: #01b3fd;
}
.vb:hover {
    color: #005580;
    text-decoration: underline;
}
.pic {
    bottom: 0;
    position: fixed;
    right: 0;
    background: #fff;
    border: 1px solid black;
    display: none;
}
.fl {
    float: left;
}
.app-container {
  overflow-x: hidden;
  height: 3000px;
}
.game-preview-page {
    width: 375px;
    height: auto;
    overflow: hidden;
    border: 1px solid black;
    float: left;
    margin: 0 auto;
}
.mx_configuration {
    width: 458px;
    position: fixed;
    left: 377px;
    top: 0;
    overflow: hidden;
    color: #565656;
}
.viewWrap {
    width: 1550px;
    height:  812px;
    .game {
        width: 810px;
        height: auto;
        margin: 0 auto;
        position: relative;
    }
}
body {
    background: #ebf1f1;
    font-family: "Microsoft YaHei","微软雅黑",Arial,"宋体";
}
a {
    text-decoration:none;   
}
.mx_bottomBarBig {
    width: 450px;
    background: #fff;
    margin-top: -8px;
    position: relative;
}
.mx_configuration .component-IMG {
    width: 400px;   
    height: auto;
    background: #fff;
}
.mx-controlP {
    width: 420px;
    max-height: 600px;
    background: #fff;
    overflow-x: hidden;
    overflow-y: scroll;
    padding: 0px 15px 20px;
}
.mx-controlP::-webkit-scrollbar {
    width: 5px;
    background-color:#c1c1c1;
}
.mx-controlP::-webkit-scrollbar-track{  
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);  
    box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    background-color:#f1f1f1;    
}
.mx-controlP::-webkit-scrollbar-thumb{  
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
    box-shadow: inset 0 0 6px rgba(0,0,0,.3);  
    background-color:#c1c1c1;
} 

.mx-title {
    font-size: 15px;
    font-weight: 900;
    color: #565656;
    height: 40px;
    line-height: 40px;
}
.mx-subtitle {
    font-size: 13px;
    font-weight: 600;
    color: #565656;
}
.help-inline {
    padding-left: 5px;
    color: #999;
    font-size: 13px;
    display: inline-block;
    font-weight: 300;
}
.mx-maroon {
    color: #d20000;
    padding-left: 2px;
    font-family: "宋体";
}
select, textarea, input[type="text"], input[type="password"], input[type="datetime"], input[type="datetime-local"], input[type="date"], input[type="month"], input[type="time"], input[type="week"], input[type="number"], input[type="email"], input[type="url"], input[type="search"], input[type="tel"], input[type="color"] {
    padding: 7px 6px;
    font-family: "微软雅黑",Arial,"宋体";
    font-size: 12px;
    color: #000;
    border-radius: 3px;
}
textarea, input[type="text"], input[type="password"], input[type="datetime"], input[type="datetime-local"], input[type="date"], input[type="month"], input[type="time"], input[type="week"], input[type="number"], input[type="email"], input[type="url"], input[type="search"], input[type="tel"], input[type="color"] {
    border-width: 1px;
    color: #858585;
    background-color: #fff;
    border-color: #d5d5d5;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    -webkit-transition-duration: .1s;
    -moz-transition-duration: .1s;
    -o-transition-duration: .1s;
    transition-duration: .1s;
    border: 1px solid #cccccc;
} 
input[type="radio"] {
    background-color: initial;
    cursor: default;
    -webkit-appearance: radio;
    box-sizing: border-box;
    margin: 3px 3px 0px 5px;
    padding: initial;
    border: initial;
}
input {
    -webkit-writing-mode: horizontal-tb !important;
    writing-mode: horizontal-tb !important;
    text-rendering: auto;
    color: initial;
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    -webkit-appearance: textfield;
    background-color: white;
    -webkit-rtl-ordering: logical;
    cursor: text;
    margin: 0em;
    font: 400 13.3333px Arial;
    padding: 1px 0px;
    border-width: 2px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
}
label.radio {
    color: #565656;
    font-size: 15px;
    display: inline-block;
    font-weight: 600;
}
input[type="text"] {
    width: 356px;
    height: 38px;
    line-height: 38px;
    padding: 0px 6px !important;
}
.mx_upImg .mx_input_short, .controlP-BG_PAGE input[type="text"] {
    width: 190px !important;
    height: 38px;
    line-height: 38px;
    padding: 0px 6px !important;
}
.mx_upImg .mx-btn {
    height: 38px;
    line-height: 38px;
}
.control-group, .controlP-CARD_NORMAL .controls {
    margin: 5px 0px !important;
    h2 {
        height: 38px;
        line-height: 38px;
    }
}
.controls {
    h2 {
        height: 38px;
        line-height: 38px;
    }
}

.mx-btn {
    display: inline-block;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
    background-image: none;
    border: 1px solid #cccccc;
    border-radius: 0;
    box-shadow: none;
    -webkit-transition: all ease .15s;
    -moz-transition: all ease .15s;
    -o-transition: all ease .15s;
    transition: all ease .15s;
    cursor: pointer;
    vertical-align: middle;
    margin: 0;
    position: relative;
    padding: 0 8px;
    line-height: 40px;
    font-size: 13px;
    height: 40px;
    border-radius: 3px;
    text-align: center;
}
.mx-btn-NORMAL {
    color: #000;
    vertical-align: bottom;
}
.mx-btn-FILLED {
    color: #fff;
    background: rgba(0, 125, 113, 1);
    vertical-align: bottom;
}
.mx-btn-MIDDLE {
    width: 120px;
}
.mx-center {
    text-align: center;
    padding: 15px;
    display: block;
    margin-left: 64px;
}
.mx-bottom-line {
    border-bottom: #cccccc solid 1px;
}
.mx-top-line {
    border-top: #cccccc solid 1px;
}
.mx_bottomBar .mx-btn {
    border: rgba(0, 125, 113, 1) solid 1px;
}
.navigationType {
    width: 432px;
    height: 80px;
    li {
        width: 125px;
        height: 40px;
        float: left;
        text-align: center;
        box-sizing: border-box;
        .btn {
            width: 100px;
            height: 32px;
            margin: 0 auto;
            margin-top: 4px;
            box-sizing: border-box;
        }
        .style1 {
            background: #858585;
        }
        .style2 {
            border-radius: 10px;
            -webkit-border-radius: 10px;
            background: #858585;
        }
        .style3 {
            border-radius: 20px;
            -webkit-border-radius: 20px;
            background: #858585;
        }
        .style4 {
            border: dashed #858585 2px;
        }
        .style5 {
            border-radius: 10px;
            -webkit-border-radius: 10px;
            border: solid #858585 2px;
        }
        .style6 {
            border-radius: 20px;
            -webkit-border-radius: 20px;
            border: dotted #858585 2px;
        }
    }
}
.pageBottom {
    width: 100%;
    height: 50px;
    position: fixed;
    background: #fff;
    bottom: 0;
    left: 0;
    z-index: 999;
    .wrap {
        width: 350px;
        margin: 5px auto;
    }
}
</style>