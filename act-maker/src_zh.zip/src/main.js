// 入口文件
import Vue from 'vue'

// 导入 vue-resource
import VueResource from 'vue-resource'
// 安装 vue-resource
Vue.use(VueResource)

// 1.1导入自己的 router.js 路由模块
import router from './router.js'
// 2.1 导入自己的 store.js 状态管理模块
import store from './store.js'

// 按需导入全局组件
import colorPicker from './components/colorPicker.vue'
Vue.component('my-color-picker', colorPicker)
import $ from 'jquery'
import Element from 'element-ui'
Vue.use(Element, { size: 'small' })


// 导入 App 根组件
import app from './App.vue'

var vm = new Vue({
  el: '#app',
  render: c => c(app),
  router, // 1.2 挂载路由对象到 VM 实例上
  store // 2.2 挂载路由对象到 VM 实例上
})